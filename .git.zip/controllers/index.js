import * as contentController from "./content/index.js";

export {
    contentController
}
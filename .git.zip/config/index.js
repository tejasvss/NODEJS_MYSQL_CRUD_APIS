import { envs } from "./envs.js";
import { connect, mysqlConnection } from "./database.js";

export { envs, connect, mysqlConnection };
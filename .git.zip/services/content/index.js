import { insertContent } from "./insertContent.js";
import { getContent } from "./getContent.js";
import { updateContent } from "./updateContent.js";

export {
    insertContent,
    getContent,
    updateContent
}
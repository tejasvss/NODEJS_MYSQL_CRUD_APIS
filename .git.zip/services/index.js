import * as contentService from "./content/index.js";

export {
    contentService
}
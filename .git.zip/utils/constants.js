const TABLES = {
    CONTENT_TABLE: 'tbl_content',
    BRANCH_TABLE: 'tbl_branch'
};


export { TABLES, };
